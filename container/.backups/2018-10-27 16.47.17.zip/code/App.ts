import { Data, animate, Override, Animatable } from 'framer'
import { log } from 'ruucm-util'

const data = Data({
  itemAreaTop: Animatable(129),
  itemAreaWidth: Animatable(335),
  itemAreaHeight: Animatable(409),
  itemWidth: Animatable(334),
  itemTop: Animatable(1),
  itemRadius: Animatable(10),
  itemDescBottom: Animatable(-172),

  closeBtnOpacity: Animatable(0),
})

export const ItemArea: Override = () => {
  return {
    top: data.itemAreaTop,
    width: data.itemAreaWidth,
    hegith: data.itemAreaHeight,
  }
}

export const ItemImg: Override = () => {
  return {
    originY: 0, // animation origin
    radius: data.itemRadius,
    onMouseDown() {
      animate.ease(data.itemAreaWidth, 320)
    },
    onTap() {
      log('onTap')
      // animate.ease(data.itemRadius, 100)
      // data.closeBtnOpacity.set(0.99)
      // animate.ease(data.itemAreaTop, 0)
      animate.ease(data.itemAreaWidth, 375)
      animate.ease(data.itemAreaHeight, 667)
    },
  }
}

export const ItemDesc: Override = () => {
  return {
    originY: 0, // animation origin
    bottom: data.itemDescBottom,
  }
}

export const CloseBtn: Override = () => {
  return {
    opacity: data.closeBtnOpacity,

    onTap(e) {
      animate.ease(data.itemWidth, 274)
      animate.ease(data.itemAreaTop, 129)
      data.closeBtnOpacity.set(0)
    },
  }
}
